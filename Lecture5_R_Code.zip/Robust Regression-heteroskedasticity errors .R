
####--------------------Dealing with Heteroskedasticity 
####----------Regression with Heteroskedasticity(Non-constant variance)
library(mlbench)
data("BostonHousing")
fit2 <- lm(medv~., data=BostonHousing)
summary(fit2)
plot(fit2)
####------------------Testing Heteroskedasticity 
##-----------Null: H0: constant Variance 
##-----------Alt : Ha: Non-constant Variance 
install.packages("car")
library(car)
ncvTest(fit2)
#### -----------------------------------Apply lmvar 
install.packages("lmvar")
library(lmvar)
####--------------------create a matrxi for the X's 
x <- cbind(BostonHousing$crim, BostonHousing$zn, BostonHousing$indus, BostonHousing$tax, BostonHousing$age, BostonHousing$b, BostonHousing$lstat, BostonHousing$nox)
colnames(x) <- c("crim", "zn", "indus", "tax", "age", "b", "lstat", "nox")
####---------------Create a matrix for the standard deviatons
x_s <- cbind(BostonHousing$crim, BostonHousing$zn, BostonHousing$indus,BostonHousing$tax, BostonHousing$age, BostonHousing$b, BostonHousing$lstat, BostonHousing$nox)
fit4 <- lmvar(BostonHousing$medv, x, x_s)
summary(fit4)
fit5 <- lm(BostonHousing$medv~BostonHousing$crim+BostonHousing$zn+BostonHousing$indus, data=BostonHousing)
summary(fit5)
AIC(fit4)
AIC(fit5)
