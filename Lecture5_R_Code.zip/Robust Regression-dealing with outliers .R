
####-----------------------------Dealing with Outliers 
####----------Robust Regression: Least Trimed Squares(LTS)
## --- LTS attempts to minimize sum of squares over 
## k observations: n-k observations do not influence the model
install.packages("robustbase")
library(robustbase)
library(mlbench)
data("BostonHousing")
fit <- lm(medv~., data=BostonHousing)
summary(fit)
plot(fit)
####------------------- Testing outliers 
install.packages("car")
library(car)
outlierTest(fit)
####-----------------------Running robust regression
library(robustbase)
ltsfit <-ltsReg(medv~., data=BostonHousing)
summary(ltsfit)
