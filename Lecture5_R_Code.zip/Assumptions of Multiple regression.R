
####-------------------------------------multiple regression  
####Assumptions of Multiple regrssion 
## varaiables are linearly related 
## errors are independently distributed 
## errors are normally distributed 
## errors are homoskedastic 
## outliers are unlikely  
## no significant multi-collinearity

### checking the assumption of multiple regression  

model <- lm(LungCap~Age+Height ,data=data)
summary(model)

### checking the assumption of independence of errors 
install.packages("car")
library(car)
durbinWatsonTest(model)

## checking the assumption of homoskedasticity  
pred <- fitted(model)
## create a data frame 
data1 <- data.frame(pred, res)
install.packages("ggplot2")
library(ggplot2)
ggplot(data=data1, aes(x=pred, y=res))+geom_point()
## testing homoskedasticity 
library(car)
ncvTest(MODEL3)
### checking the assumption of normality of errors 
shapiro.test(res)

###### Checking Multicollinearity
##### Multicollinearity happens when one or more regressors 
#### are correlated with each other 
#### Don't run this section. 
library(mlbench)
library(help="mlbench")
data("BostonHousing")
str(BostonHousing)

##### Install the packages
install.packages("ggplot2")
install.packages("car")
install.packages("caret")
install.packages("corrplot")
library(ggplot2)
library(car)
library(caret)
library(corrplot)

###### Use clvdata1 for this section 
###### Linear Regression Modeling 
##### Check assumptions of Linear regression modeling in Prem Mann Book. 

##### Checking correlation between regressors/Independent Variables 
data <- subset(BostonHousing, select = -c(medv))
numeric <- data[sapply(data, is.numeric)]
corrleation <- cor(numeric)
print(corrleation)
corrplot(corrleation)

###### Running Regression 
model <- lm(data$futureMargin~., data=data)
summary(model)
######checking multicollinearity by VIF
vif(model)

##### Dropping the variables suffering from Multicollenarity 

data3 <- subset(data, select = -c(nOrders, nItems))
df1= as.data.frame(data3)
model1 <- lm(data3$futureMargin~., data=df1)
summary(model1)
vif(model1)

##### Principal Component Analysis
#### when not sure which regressors to be dropped
install.packages("pls")
library(pls)
et.seed(1000)

Pca_model <- pcr(data$futureMargin~., data=data, scale=TRUE, validation="CV")
summary(Pca_model)
validationplot(Pca_model)
validationplot(Pca_model, val.type = "R2")






