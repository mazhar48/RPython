
####*****************Model selection*********************
##---------------The most parsimonious model
##----------Parsimonious model means model with as few relevant 
##----------variable as possible 
####---------------Parsimonious model BY AIC: 
library(mlbench)
data("BostonHousing")
install.packages("MASS")
library(MASS)
attach(BostonHousing)
####------------------------run step function 
step(lm(medv~crim+zn+indus+chas+nox+rm+age+dis+rad+tax+ptratio+b+lstat, data=BostonHousing), direction="backward")
step(lm(medv~crim+zn+indus+chas+nox+rm+age+dis+rad+tax+ptratio+b+lstat, data=BostonHousing), direction="both")
####-------------------include all 
null <- lm(medv~1, data=BostonHousing)
full <- lm(medv~., data=BostonHousing)
step(null, scope=list(lower=null, upper=full), direction="both")
####-------------The most parsimonious model:
model <-lm(medv~crim+zn+chas+nox+rm+dis+ptratio+b+lstat+tax+rad+b, data=data)
summary(model)

####------------------------Model selection by R-squared 
library(mlbench)
data("BostonHousing")
model2 <- lm(medv~., data=BostonHousing)
summary(model2)
model3 <- lm(medv~lstat, data=BostonHousing)
summary(model3)
install.packages("leaps")
library(leaps)
model4 <-regsubsets(medv~., data=BostonHousing)
summary(model4)
reg.summary <- summary(model4)
reg.summary$rsq
plot(model4, scale="adjr", main="Adjusted R-Sq")
#### -------The most parsimonious relevant model is:
model5 <-lm(medv~zn+chas+nox+rm+dis+ptratio+b+lstat, data=data)
summary(model4)

