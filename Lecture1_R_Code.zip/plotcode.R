##### set te directory first using the following commands:
getwd()
setwd()
##### import data in csv format using the following command
data <- read.csv(file.choose())
attach(data)
#### R codes for Plot #####
#### Remember to attach data using attach(data)command before running codes. 
cor(Age, Height)
cor(Age, LungCap)

cor(Age, LungCap, method="spearman")

cor(Age, LungCap, method="kendall")

cor.test(Age, LungCap, method="pearson", conf.level=.99)

cor.test(Age, LungCap, method="spearman", conf.level=.99, exact=F)

pairs(data)

pairs(data[,1:3], col=4, pch=05)

cor(data[,1:3])
####-----------------------------Scatterplot codes 
plot(Age, Height)

plot(Age, Height, main="Scatter Plot", xlab="Age", ylab="Height")

plot(Age, Height, main="Scatter Plot", xlab="Age", ylab="Height", las=1)

plot(Age, Height, main="Scatter Plot", xlab="Age", ylab="Height", las=1, xlim=c(0,25))

plot(Age, Height, main="Scatter Plot", xlab="Age", ylab="Height", las=1, xlim=c(0,25),col=2)

plot(Age, Height, main="Scatter Plot", xlab="Age", ylab="Height", las=1, xlim=c(0,25),col=2, cex=.5)

abline(lm(Height~Age))

abline(lm(Height~Age), col=4)

abline(lm(Height~Age), col=4, lwd=3)

text(x=2.4, y=11, label="scatter plot", adj=1, cex=.50, col=4)

abline(h=mean(Lungcap),col=4, lwd=4)

####--------------------------- Barplot codes 
count <- table(Gender)

percent <- table(Gender)/725

barplot(count)

barplot(percent)

barplot(percent, main="TITLE", xlab="Gender", ylab="%")

barplot(percent, main="TITLE", xlab="Gender", ylab="%", las=1)

barplot(percent, main="TITLE", xlab="Gender", ylab="%",las=1,names.arg=c("female", "male") )
####------------------------------Subsetting and Slicing 
mean(Age[Gender=="female"])

mean(Age[Gender=="male"])

femsmoke <- Gender=="female" & Smoke=="yes"

femdata <- data[Gender=="female", ]

maledata <- data[Gender=="male", ]

maleover15 <- data[Gender=="male" & Age >15, ]

moredata <- cbind(data, femsmoke)

temp <- Age>15

temp

temp1 <- as.numeric(Age>15)
temp1
####---------------------------------- Normal Distribution Codes 
pnorm(q=70, mean=75, sd=5, lower.tail=F)

pnorm(q=1, mean=0, sd=1, lower.tail=F)

qnorm(p=.35, mean=0, sd=1, lower.tail=T)

x1<- seq(from=55, to=95, by=.50)

density1 <- dnorm(x1, mean=75, sd=5)

plot(x1, density1, type="l")

plot(x1, density1, type="l", lwd=3, col=2, las=1, main="X~Normal:mean=70, SD=5", xlab="x", ylab="probability Density")

####---------------------------------- grouping and calculation of group mean

catheight2 <- cut(Height, breaks=c(0,50,55,60,65,70,100), labels=c("A", "B", "C", "D", "E", "F" ))

catheight2 <- cut(Height, breaks=c(0,50,55,60,65,70,100), labels=c("A", "B", "C", "D", "E", "F" ), right=F)

mean(LungCap[catheight2=="A"])

mean(LungCap[catheight2=="B"])

mean(LungCap[catheight2=="c"])

mean(LungCap[catheight2=="D"])

mean(LungCap[catheight2=="E"])

mean(LungCap[catheight2=="F"])

plot(Age[Smoke=="no"], LungCap[Smoke=="no"], col=4, xlab="Age", ylab="LungCap", ylim=c(0,15), main="LungCap vs Age, Smoke")

points(Age[Smoke=="yes"], LungCap[Smoke=="yes"], col=2, pch=16)


