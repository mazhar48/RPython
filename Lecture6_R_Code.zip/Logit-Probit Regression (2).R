

####-----------------------------------Regression with binary variable 
data< read.csv(file.choose())
attach(data)
names(data)
####---------------------------------Assumptions 
##----- 1. Linear between x and log y 
##------2. independence of errors 
##------3. errors don't have to be normally distributed 
##------4. No perfect muliticollinearity between regressors 
install.packages("ggplot2")
library(ggplot2)
ggplot(data, aes(x=,y=))+ geom_point()+stat_smooth(method="glm", method.args=list(family="binomial"), se=FALSE)

model <- glm(mobile~income+hours+age, data=data, family=binomial(link="logit"))

summary(model)
expnd <- exp(coef(model))
print(coeff)
## constructing confidence interval 
intcon <- exp(confint(model, level=.99))
##--------------------------------------Goodness of fit of Binary model 
## first we checke whether independent variables 
## explains the dependent variable or model is correct or not. 
## for this we use Hosmer- Lemeshaw test. 
install.packages("ResourceSelection")
library(ResourceSelection)
hoslem.test(data$dependentvariable, fitted(model))

####-------------------------------------predicting with new data 
newdata <- data.frame(x1=20, x2=30)
predict(model, data=newdata, type="response")

####-----------------------------------checking overdispersion 
###-----overdispersion means discrepency between observed value of y and 
###-----predicted value of y; if present it distorts the fit of the model. 

install.packages("arm")
library(arm)
pred <- predict(model)
res <- resid(model)
binnedplot(pred,res)
####--------------------if standard errors fall between +2 to -2 
###--------------then there is no overdispersion in the model. 
## compute Psuedo R-square
install.packages("fmsb")
library(fmsb)
Nagelkerke(model)
## compute all Psuedo R-square 
install.packages("BaylorEdPsych")
library(BaylorEdpsych)
PsuedoR2(model)





