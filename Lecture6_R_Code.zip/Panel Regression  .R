
####---------------------- Panel Regression Analysis 
data <- read.csv(file.choose())
attach(data)
names(data)
####-----------------Panel Regression: Method-1
yeardum <- as.factor(year)
statedum <- as.factor(state)
panel_model <- lm(allmort~spircons+unrate+perinc+beertax+mlda+jaild+vmiles+statedum+yeardum)
panel_model2 <- lm(allmort~spircons+unrate+perinc+beertax+mlda+jaild+vmiles+statedum+yeardum+comserd+pop1517)
panel_model3 <- lm(allmort~spircons+unrate+perinc+beertax+mlda+jaild+vmiles+statedum+yeardum+comserd+pop1517+pop1820+breath)
panel_model4 <- lm(allmort~spircons+unrate+perinc+beertax+mlda+jaild+vmiles+statedum+yeardum+comserd+pop1517+pop1517+breath+pop2124)

####------------------------- Producing Regression Table 
install.packages("stargazer")
library(stargazer)
getwd()
setwd("C:/Users/Sarmin Akter/Desktop/R coding")
getwd()
stargazer(panel_model, panel_model2, panel_model3, panel_model4, digit=3, type="html", out="report.htm", title="Regression Results", df=FALSE)
####------------------------Alternative way of making Table 
install.packages("texreg")
library(texreg)
htmlreg(list(panel_model, panel_model2, panel_model3, panel_model4), file="Model.docx", caption="regression", caption.above = TRUE, digits=3)

####----------------------------Panel Regression: Method-2
install.packages("plm")
library(plm)
model_1 <- lm(allmort~beertax, data=data)
model_2 <- plm(allmort~beertax+state, data=data)
model_3 <- plm(allmort~beertax+state+year+spircons+unrate,
           index=c("state", "year"), model="within", effect="twoways",
           data=data)
model_4 <-  plm(allmort~beertax+state+year+spircons+unrate+mlda+jaild,
            index=c("state", "year"), model="within", effect="twoways",
            data=data)
model_5 <- plm(allmort~beertax+state+year+spircons+unrate+mlda+jaild+comserd,
            index=c("state", "year"), model="within", effect="twoways",
            data=data)
model_6 <- plm(allmort~beertax+state+year+spircons+unrate+mlda+jaild+comserd+perinc,
            index=c("state", "year"), model="within", effect="twoways",
            data=data)
model_7 <- plm(allmort~beertax+state+year+spircons+unrate+mlda+jaild+comserd+perinc+vmiles,
            index=c("state", "year"), model="within", effect="twoways",
            data=data)
rob_se <- list(sqrt(diag(vcovHC(model_1, type="HC1"))), 
           sqrt(diag(vcovHC(model_2, type="HC1"))), 
           sqrt(diag(vcovHC(model_3, type="HC1"))), 
           sqrt(diag(vcovHC(model_4, type="HC1"))), 
           sqrt(diag(vcovHC(model_5, type="HC1"))),
           sqrt(diag(vcovHC(model_6, type="HC1"))),
           sqrt(diag(vcovHC(model_7, type="HC1"))))
stargazer(model_1,model_2,model_3,model_4,model_5, model_6, model_7,
          digit=3,se =rob_se, type="html", out="Reg.htm", title="Regression Results", df=FALSE)

??stargazer

