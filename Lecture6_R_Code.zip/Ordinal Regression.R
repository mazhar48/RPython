

###-----------------------------------Ordinal Regression 
## we have one dependent varaiable with four level:
## 1 -not satisfactory 4- very satisfatory 
## three independent variables: one string with two levels: Buisness traveller
## pleasure traveller
## imprice with three levels: 1- not important 3- very important 
## age continuous variable 

## we check whether satisfaction level depends on other independet variables 

## first we create base reference for imprice and type variables
install.packages("MASS")
library(MASS)

data$Type <- relevel(data$Type, ref="Business Traveller")
data$Imprice <- relevel(factor(data$Imprice), ref="3")

## to run ordinal regression load the package MASS

install.packages("MASS")
library(MASS)

model <- polr(factor(Satisfaction)~Age+Imprice+Type, data=data, method="logistic")

summary(model)

## since p-values are not generated, we must compute p-values:

cft <- coef(summary(model))

print(cft)

pv <- pnorm(abs(cft[,"t value"]), lower.tail = F)*2

print(pv)

cft <- cbind(cft,"p-value"=pv)

print(cft)

## taking anti log of co-efficients 

expd <- exp(coef(model))

print(expd)

## constructing confidence interval 

cof <- exp(confint(model))

## measuring the goodness of fit test 

model0 <- polr(factor(satisfaction)~1, data=data, method="logistic")

model1 <- polr(factor(satisfaction)~age+type+imprice, data=data, method="logistic")

LL0 <- logLik(LL0)
LL1 <- loglik(LL1)

## macfadden Psuedo measure of R-square 

Macfadden <- 1- (LL1/LL0)

print(Macfadden)

## coxsnell measure of Psuedo R-square

n <- nrows(satisfaction)

coxsnell <- 1 - exp(n/2)*(LL1/LL0)

print(coxsnell)

## nagelkerke measure of Psuedo R-square 

nagel <- (1 - exp(n/2)*(LL1/LL0))/(1 - exp(LL0)^(n/2))

print(nagel)





