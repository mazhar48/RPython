
#### ------------------Dealing with departure from Normality of Errors 
library(mlbench)
library(help="mlbench")
data("BostonHousing")
str(BostonHousing
attach(BostonHousing)
model <- lm(medv~., data=BostonHousing)
summary(model)
par(mfrow=c(2,2))
plot(model)
qqnorm(residuals(model))
qqline(residuals(model))
hist(BostonHousing$medv)
####---------------------- variable transformation  
#### --------------------- sqrt(medv)
#### --------------------- log(medv)
BostonHousing$medv.sq <- sqrt(BostonHousing$medv)
BostonHousing$medv.ln <- log(BostonHousing$medv)
hist(BostonHousing$medv.sq)
hist(BostonHousing$medv.ln)
#### ----------------run regression with transformed variable
model2 <- lm(medv.sq~., data=BostonHousing)
summary(model2)
qqnorm(residuals(model2))
qqline(residuals(model2))
#### ----------------Run regression once again with medv.ln
model3 <- lm(medv.ln~., data=BostonHousing)
summary(model3)
qqnorm(residuals(model3))
qqline(residuals(model3))
####---------------Box-Cox Transformation 
install.packages("MASS")
library(MASS)
bc <- boxcox(BostonHousing$medv~., data=BostonHousing)
trans <- bc$x[which.max(bc$y)]
trans
####--------------------run box-cox transformed regression
model4 <- lm(medv^trans~., data=BostonHousing)
summary(model4)
par(mfrow=c(2,2))
plot(model4)
