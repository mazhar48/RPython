

###------------------Visualisation in R---------------------------

## Reading dataset from web 

mpg <- read.csv("http://goo.gl/uEeRGu")
install.packages("ggplot2")
library(ggplot2)
# Scatterplot

###-------------------- aesthetice
install.packages("ggplot2")
library(ggplot2)
attach(data3)
colnames(data3)<- c("Flim", "Genre", "Critic.rating", "Audience.rating", "Budgetmillions", "Year")

data3$Year<- factor(data3$Year)
ggplot(data=data3, aes(x=`Critic.rating`, y=`Audience.rating`, color=Genre))+geom_point()

ggplot(data=data3, aes(x=`Critic.rating`, y=`Audience.rating`, color=Genre))+geom_point()

q <- ggplot(data=data3, aes(x=`Critic.rating`, y=`Audience.rating`))

q+geom_point()



g <- ggplot(mpg, aes(cty, hwy))

g + geom_point() + 
  geom_smooth(method="lm", se=F) +
  labs(subtitle="mpg: city vs highway mileage", 
       y="hwy", 
       x="cty", 
       title="Scatterplot with overlapping points", 
       caption="Source: midwest")


## Jittered plot


g <- ggplot(mpg, aes(cty, hwy))
g + geom_jitter(width = .5, size=1) +
  labs(subtitle="mpg: city vs highway mileage", 
       y="hwy", 
       x="cty", 
       title="Jittered Points")


## More points are revealed now. More the width, more the points are moved 
## jittered from their original position.

## Ordered Bar Chart

# Prepare data: group mean city mileage by manufacturer.

cty_mpg <- aggregate(mpg$cty, by=list(mpg$manufacturer), FUN=mean)  # aggregate
colnames(cty_mpg) <- c("make", "mileage")  # change column names
cty_mpg <- cty_mpg[order(cty_mpg$mileage), ]  # sort
cty_mpg$make <- factor(cty_mpg$make, levels = cty_mpg$make)  # to retain the order in plot.
head(cty_mpg, 4)

# The X variable is now a factor, let's plot.

ggplot(cty_mpg, aes(x=make, y=mileage)) + 
  geom_bar(stat="identity", width=.5, fill="tomato3") + 
  labs(title="Ordered Bar Chart", 
       subtitle="Make Vs Avg. Mileage", 
       caption="source: mpg") + 
  theme(axis.text.x = element_text(angle=65, vjust=0.6))



# Histogram on a Continuous (Numeric) Variable

g <- ggplot(mpg, aes(displ)) + scale_fill_brewer(palette = "Spectral")

g + geom_histogram(aes(fill=class), 
                   binwidth = .1, 
                   col="black", 
                   size=.1) +  # change binwidth
  labs(title="Histogram with Auto Binning", 
       subtitle="Engine Displacement across Vehicle Classes")  

g + geom_histogram(aes(fill=class), 
                   bins=5, 
                   col="black", 
                   size=.1) +   # change number of bins
  labs(title="Histogram with Fixed Bins", 
       subtitle="Engine Displacement across Vehicle Classes") 
#------------------------- histogram and density curve 

s <- ggplot(data=data3, aes(x= Budgetmillions))

s+geom_histogram(aes(fill=Genre), color="Black")
q
s+geom_density(bins=10)

s+geom_density(aes(fill=Genre))

s+geom_density(aes(fill=Genre), position="stack")

###### Barchart

g <- ggplot(mpg, aes(manufacturer))
g + geom_bar(aes(fill=class), width = 0.5) + 
  theme(axis.text.x = element_text(angle=65, vjust=0.6)) + 
  labs(title="Histogram on Categorical Variable", 
       subtitle="Manufacturer across Vehicle Classes") 


## Box Plot

g <- ggplot(mpg, aes(class, cty))
g + geom_boxplot(varwidth=T, fill="plum") + 
  labs(title="Box plot", 
       subtitle="City Mileage grouped by Class of vehicle",
       caption="Source: mpg",
       x="Class of Vehicle",
       y="City Mileage")

g <- ggplot(mpg, aes(class, cty))
g + geom_boxplot(aes(fill=factor(cyl))) + 
  theme(axis.text.x = element_text(angle=65, vjust=0.6)) + 
  labs(title="Box plot", 
       subtitle="City Mileage grouped by Class of vehicle",
       caption="Source: mpg",
       x="Class of Vehicle",
       y="City Mileage")
#------------------------------ boxplot and line 

u<- ggplot(data=data3, aes(x=Genre, y=Audience.rating, color=Genre))

u+geom_boxplot(size=1)

u+geom_boxplot(size=1)+geom_jitter()
u+geom_jitter()+geom_boxplot(size=1, alpha=0.50)

r <- ggplot(data=data3, aes(x=Critic.rating, y=Audience.rating, color=Genre))

r+geom_point()+geom_smooth(fill=NA)

#----------------------- using facets 

colnames(data3)<- c("Film", "Genre", "Critic.rating", "Audience.rating", "Budgetmillions", "Year")

s <- ggplot(data=data3, aes(x=`Critic.rating`, y=`Audience.rating`, color=Genre))

s+geom_point(size=2)+facet_grid(Genre~Year)

## Time Series Plot From a Time Series Object

## From Timeseries object (ts)
install.packages("zoo")
library(zoo)
install.packages("ggfortify")
library(ggfortify)

# Plot 
autoplot(AirPassengers) + 
  labs(title="AirPassengers") + 
  theme(plot.title = element_text(hjust=0.5))

## Time Series Plot From Long Data Format
# Multiple Time Series in Same Dataframe Column

data(economics_long)
install.packages("lubridate")
library(lubridate)
df <- economics_long[economics_long$variable %in% c("psavert", "uempmed"), ]
df <- df[lubridate::year(df$date) %in% c(1967:1981), ]

# labels and breaks for X axis text
brks <- df$date[seq(1, length(df$date), 12)]
lbls <- lubridate::year(brks)
library(ggplot2)
# plot
ggplot(df, aes(x=date)) + 
  geom_line(aes(y=value, col=variable)) + 
  labs(title="Time Series of Returns Percentage", 
       subtitle="Drawn from Long Data format", 
       caption="Source: Economics", 
       y="Returns %", 
       color=NULL) 





