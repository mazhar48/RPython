
##--------------------------------------------- Three way ANOVA 
##------------------ Assumptions 
## Dependent variable is normally distributed 
## outliers in dependent variable are unlikely
## equality of group variances
data <- read.csv(file.choose())
attach(data)
names(data)
## Weight dependent variable, Diet, Gender, and Smoke Categorical Variable 
aov6 <- aov(Weight~Diet+Gender+Smoke+Diet*Gender+Diet*Smoke+Gender*Smoke+Diet*Gender*Smoke, data=data)
summary(aov6)
## if the F statistics on third interaction term turns out significant 
## then we compute second order main effects. 
####------------------------- Simple second order Interaction effect
## we compute the inlfluence of Diet and Smoke on effort for factor Gender 

data1 <- data[data$Gender=="Female",]
aov2 <- aov(Weight~Diet*Smoke, data=data1)
summary(aov2)
####---------------------------- For Smoke 
data2 <- data[data$Smoke=="No",]
aov3 <- aov(Weight~Diet*Gender, data=data2)
summary (aov3)

## if the second order intereaction effect 
## becomes significant, then we compute simple main effects
#####------------------------------------------simple main effects 
## we compute the effect of Diet factor at every level 
## of Smoke and Gender 
## first we create a data frame 

data3 <- data[data$Gender=="Female" & data$Smoke=="No",]
aov4 <- aov(Weight~Diet, data=data3)
summary(aov4)
TukeyHSD(aov4)
data4 <- data[data$Gender=="Male" & data$Smoke=="Yes",]
aov5 <- aov(Weight~Diet, data=data4)
summary(aov5)
TukeyHSD(aov5)





