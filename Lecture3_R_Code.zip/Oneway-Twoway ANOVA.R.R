
##---------------------------------------- oneway ANOVA Analysis 
##---------------ASSUMPTONS
## Dependent variables are normally distributed 
## outliers are unlikely 
## equal group variances 
## test the equality of group variances
data <- read.csv(file.choose())
attach(data)
install.packages("car")
library(car)
leveneTest(data$Weight, data$Diet)
aov1 <- aov(Weight~Diet, data=data)
summary(aov1)
####---------- if group variaces are not equal then run welch test
oneway.test(Weight~Diet, data=data, var.equal = F)

## ------------------------------------ Two way ANOVA Analysis 
## Dependent variables are normally distributed 
## outliers are unlikely 
## equal group variances 
## Weight is dependent, Diet and Gender and Smoke are categorical variable 
aov2 <- aov(Weight~Diet+Gender+Diet*Gender, data=data)
summary(aov2)

### ---------------Simple Main effects of Two way ANOVA:
## simple main effect is the effect of a factor
## at every other level of the other facto 
## Test the effect of Gender on effort on each Diet Group
data2 <- data[data$Diet=="A",]

####----------------------------------- Run the ANOVA test 
aov3 <- aov(Weight~Gender, data=data2)
summary(aov3)

####------------ Run Tukey HSD test to check for pairwise difference
TukeyHSD(aov3)
data3 <- data[data$Diet=="B",]
aov4 <- aov(Weight~Gender, data=data3)
summary(aov4)
TukeyHSD(aov4)

####--- let's test the effect of Diet on Weight on each gender group 
##------------------ first create a new data frame 
data4 <- data[data$Gender=="Female",]
aov5 <- aov(Weight~Diet, data=data4)
summary(aov5)
TukeyHSD(aov5)















