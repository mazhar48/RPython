
####------------------------------------ MANOVA Analysis 
####------------------------------------Assumptions 
## dependent variables are normally distributed 
## outliers are unlikely 
## no multicollinearity between dependent variables 
## group co-variances are equal 
## group variances are equal  
data <- read.csv(file.choose())
attach(data)
names(data)

## Weight dependent variable, stress dependent variable, and 
## Diet, Smoke, and Gender categorical variable 
install.packages("biotools")
library(biotools)
data1 <- data[c(2,3)]

## run boxm test to test equality of co-variances 
boxM(data1, data$Diet)

## create a matrix using dependent variables only 
mat <- cbind(data$Weight, data$Stress)
model<- manova(mat~data$Gender)  
summary(model, test="Wilks") ## when co-variances are equal 
summary(model, test="Pillai")







