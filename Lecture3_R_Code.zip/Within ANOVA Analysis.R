
####-------------------------------------Within ANOVA Analysis 
####------------------------- Assumptions 
## dependent variables are normally distributed 
## no significant outliers in dependent variables 
## there is spericity **(Variances of differences between dependentvariable are equal) 
data <- read.csv(file.choose())
attach(data)
names(data)

## we want to see whether subejcts weight differ at three diet 
## moments: beiginning, middle, and end 
## dependet variable is weight and factor is Diet Moments or Time

####---------------- Build a matrix for different factor levels
moments <- c("Beiginning", "Middle", "End ")
moments_frm <- data.frame(moments)

####------------------ we create a matrix with subjectw wieght
weight_mat <- cbind(data$Weight.beg, data$Weight.mid, data$Weight.end)
print(weight_mat)
model <- lm(weight_mat~1)
summary(model)
install.packages("car")
library(car)
model2 <- Anova(model, idata= moments_frm, idesign=~moments, type="III")
summary(model2, multivariate=F) ## F because we don't want MANOVA results

####------------------------------ within ANOVA paired comparison 
####--------------- first we reshape the data using melt function 
install.packages("reshape2")
library(reshape2)
data1 <- melt(data)
View(data1)
colnames(data1) <- c("group", "weight")
View(data1)
model <- aov(weight~group, data=data1)
summary(model)
TukeyHSD(model)

##-------------- to run bonferroni test of paried comparison 
pairwise.t.test(data1$weight, data1$group, p.adjust.method = "bonferroni")

####---------------------------Friedman Test 
####-------------- It is a nonparametric test for Within ANOVA
####------------- Instead of Mean, Medians are compared
data <- read.csv(file.choose())
attach(data)
names(data)
####--------------------- Build a matrix for different weights 
mat <- cbind(data$Weight.beg, data$Weight.mid, data$Weight.end)
friedman.test(mat)







