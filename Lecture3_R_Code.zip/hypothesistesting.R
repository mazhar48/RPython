
####---------------------------------------Hypothesis Testing
####----------------------R codes for one population mean t-test
 t.test(LungCap, mu=8, alternative="less than", conf.level = .95)
 
 t.test(LungCap, mu=8, alt="less", conf = .95)
 
 t.test(LungCap, mu=8, alt="two.sided", conf = .95)
 
 ## by default if we write mu=8, test will be conducted as two.sided test.
 t.test(LungCap, mu=8, conf=.99)
 attributes(Test)
 Test$p.value
 
 ####-----------------------R codes for Two-Population Mean test
 
 t.test(LungCap~Smoke, mu=0, alt="less", conf=.99, var=F, paried=F)
  
 t.test(LungCap~Smoke, mu=0, alt="less", conf=.99, var=T, paried=F)
 
 t.test(LungCap~Smoke)
  
####--------- R codes for Mann Whiteney OR Wilcoxon Rank Sum  test
install.packages("psych")
library(psych)
wilcox.test(LungCap~Smoke, mu=0, alt="two.sided", conf.int="T", conf.level=.99, paired=F, exact=F, correct=T)

wilcox.test(LungCap~Smoke, conf.int="T", conf.level=.99)

####------------------------------ To see the group meidans
describeBy(LungCap, Smoke)
 
#### -------------------------------------- Paired t-test
####--------------------------Assumptions 
## Population standard deviation of paried differences are unknown 
## Small sample size (n<30) & population of paried differences is normally distributed
####--------------------------------------R codes for Paired Test
 boxplot(Before, After)

 t.test(Before, After, mu=0, alt="two.sided", paired=T, conf=.99) 
 
 ####-------------------------------- wilcoxon signed rank test
 ## No assumption of normality of population 
 ## for sample size more than 15, we use normal distributio
 #### ------------------------------R codes for Signed Rank Test 
 
 wilcox.test(Before, After, mu=0, alt="two.sided", conf.int=T, conf.level=.99, paired=T, exact=F, correct=T)
 
 #####------------------------------------- ANOVA test
 #### -------------------------- Assumptions of ANOVA 
 ## Population is normally distributed 
 ## Equal population variances 
 ## Independent samples 
 ## ANOVA is always right tailed 
 #####-------------------------------- R codes for ANOVA Test 
 boxplot(WeightLoss~Diet)
 
 aov(WeightLoss~Diet)
 
 ANOVA <- aov(WeightLoss~Diet)
 
 summary(ANOVA)
 
 TukeyHSD(ANOVA)
 
 plot(TukeyHSD(ANOVA), las=1)
 
 ##### ---------------------------------- Kruskal-Wallis (K-W) test
 ##### -----------------------Assumptions of K-W test 
 ## EachSample size must be at least 5
 ## No assumption of normality of populations 
 ## Each population has same shape which doesn't mean normal shape
 ## K-W test is always right-tailed 
 install.packages("psych")
 library(psych)
 kruskal.test(WeightLoss~Diet)
 describeBy(Weightloss, Diet)
 
 
 
