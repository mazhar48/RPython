#Package for time series analysis and plot

library(forecast)
library(ggplot2)

#The number of international passengers per month on an airline in the united states
#were obtained from the Fedral Aviation Administration for the period 1946-1960.
#The company used the data to predict future demand before ordering new aircraft and
#training aircrew. The data are available as a time series in R and is named 
#AirPassengers.

### Read a data

dat <- read.csv(file.choose())
names(dat)

# Convert data into time series format
tsdat <- ts(dat$Passengers, start=c(1949, 1), end=c(1960, 12), frequency=12)
class(tsdat)
tsdat
#
autoplot(tsdat) +
  ggtitle("Forecasting Air Passengers") +
  ylab("Passengers (thousands)") +
  xlab("Year")

# decomposition
sdecom <- stl(tsdat, s.window="period")
autoplot(sdecom)

# Seasonal decomposition
ggseasonplot(tsdat, year.labels=TRUE, year.labels.left=TRUE) +
  ylab("Passengers (thousands)") +
  ggtitle("Seasonal plot: Forecasting Air Passengers")

########### Forecasting series ########

# Exponential Smoothing method

fit1 <- hw(tsdat,seasonal="additive", h=36)

autoplot(tsdat) +
  autolayer(fit1, series="HW additive forecasts") +
  xlab("Year") +
  ylab("Passengers (thousands)") +
  ggtitle("Forecasting Air Passengers") 


fit2 <- hw(tsdat,seasonal="multiplicative", h=36)

autoplot(tsdat) +
  autolayer(fit1, series="HW multiplicative forecasts") +
  xlab("Year") +
  ylab("Passengers (thousands)") +
  ggtitle("Forecasting Air Passengers") 


autoplot(tsdat) +
  autolayer(fit1, series="HW additive forecasts", PI=FALSE) +
  autolayer(fit2, series="HW multiplicative forecasts",
            PI=FALSE) +
  xlab("Year") +
  ylab("Passengers (thousands)") +
  ggtitle("Forecasting Air Passengers") +
  guides(colour=guide_legend(title="Forecast"))


# ARIMA Models

#Arima(data, order=c(p,d,q))
Arima(tsdat, order = c(1,1,1))

#Seasonal ARIMA
# Arima(data, order=c(p,d,q), seasonal = list(order=c(P,Q,D),period=S))
Arima(tsdat, order = c(1,1,1), seasonal = list(order=c(1,1,0),period=12))

# Finding Order of Arima: Order based on best model according to AIC criterion

auto.arima(tsdat)

fit <- Arima(tsdat, order = c(2,1,1), seasonal = list(order=c(0,1,0),period=12))

checkresiduals(fit)

autoplot(forecast(fit, h=36))








